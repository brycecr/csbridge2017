import stanford.karel.*;

public class RandomPainter extends SuperKarel {
	
	public void run() {
		// your code goes here...
	}

}
