import stanford.karel.*;

public class BuildKarluvMost extends SuperKarel {
	
	public void run() {
		// your code here
	}

}
